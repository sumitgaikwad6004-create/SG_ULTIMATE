# SG ULTIMATE — Build & Run Guide

To build a release APK:
```bash
./gradlew assembleRelease
```

To build a debug APK:
```bash
./gradlew assembleDebug
```
Generated APK:
`app/build/outputs/apk/release/app-release.apk`
