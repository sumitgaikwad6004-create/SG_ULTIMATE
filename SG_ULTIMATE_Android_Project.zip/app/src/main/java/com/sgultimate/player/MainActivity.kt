package com.sgultimate.player

import android.app.PictureInPictureParams
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.sgultimate.player.player.Media3PlayerManager
import com.sgultimate.player.ui.theme.SgUltimateTheme

class MainActivity : ComponentActivity() {

    private lateinit var playerManager: Media3PlayerManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        playerManager = Media3PlayerManager(this)

        setContent {
            SgUltimateTheme {
                MainAppContainer(
                    playerManager = playerManager,
                    onEnterPiP = { enterPictureInPictureModeCompat() }
                )
            }
        }
    }

    private fun enterPictureInPictureModeCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        playerManager.release()
    }
}