package com.sgultimate.player.player

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.cache.NoOpCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.DownloadService
import java.io.File
import java.util.concurrent.Executors

@OptIn(UnstableApi::class)
class Media3DownloadHelper private constructor(private val context: Context) {
    companion object {
        private const val DOWNLOAD_DIR = "downloads"
        @Volatile private var instance: Media3DownloadHelper? = null
        fun getInstance(context: Context): Media3DownloadHelper =
            instance ?: synchronized(this) { instance ?: Media3DownloadHelper(context.applicationContext).also { instance = it } }
    }

    private val databaseProvider = StandaloneDatabaseProvider(context)
    val downloadCache: SimpleCache by lazy {
        val dir = File(context.getExternalFilesDir(null) ?: context.filesDir, DOWNLOAD_DIR)
        SimpleCache(dir, NoOpCacheEvictor(), databaseProvider)
    }

    val downloadManager: DownloadManager by lazy {
        DownloadManager(context, databaseProvider, downloadCache, DefaultHttpDataSource.Factory(), Executors.newFixedThreadPool(4))
    }

    fun startDownload(uri: Uri, title: String) {
        val request = DownloadRequest.Builder(uri.toString(), uri).setData(title.toByteArray()).build()
        DownloadService.sendAddDownload(context, VideoDownloadService::class.java, request, false)
    }

    fun removeDownload(uri: Uri) {
        DownloadService.sendRemoveDownload(context, VideoDownloadService::class.java, uri.toString(), false)
    }
}