package com.sgultimate.player.player

import android.app.Notification
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadNotificationHelper
import androidx.media3.exoplayer.offline.DownloadService
import com.sgultimate.player.SgUltimateApp

@OptIn(UnstableApi::class)
class VideoDownloadService : DownloadService(
    2001,
    DEFAULT_FOREGROUND_NOTIFICATION_UPDATE_INTERVAL,
    SgUltimateApp.PLAYBACK_CHANNEL_ID,
    com.sgultimate.player.R.string.app_name,
    0
) {
    override fun getDownloadManager(): DownloadManager =
        Media3DownloadHelper.getInstance(this).downloadManager

    override fun getScheduler() = null

    override fun getForegroundNotification(downloads: MutableList<Download>, notMetRequirements: Int): Notification {
        return DownloadNotificationHelper(this, SgUltimateApp.PLAYBACK_CHANNEL_ID)
            .buildProgressNotification(this, com.sgultimate.player.R.drawable.ic_launcher_foreground, null, null, downloads, notMetRequirements)
    }
}