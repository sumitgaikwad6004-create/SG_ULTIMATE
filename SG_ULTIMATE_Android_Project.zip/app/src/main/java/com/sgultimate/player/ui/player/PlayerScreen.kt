package com.sgultimate.player.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView
import com.sgultimate.player.player.Media3PlayerManager
import com.sgultimate.player.ui.components.GestureDetectorBox

@Composable
fun PlayerScreen(
    playerManager: Media3PlayerManager,
    videoTitle: String,
    onBack: () -> Unit,
    onEnterPiP: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = playerManager.exoPlayer
                    useController = false
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        GestureDetectorBox(
            modifier = Modifier.fillMaxSize(),
            onSingleTap = { /* Toggle Controls */ },
            onDoubleTapLeft = { playerManager.seekRelative(-10000L) },
            onDoubleTapRight = { playerManager.seekRelative(10000L) },
            onBrightnessDelta = { /* HUD Brightness */ },
            onVolumeDelta = { /* HUD Volume */ },
            onSeekDelta = { /* HUD Seek */ },
            onGestureEnd = { }
        ) {
            // High-definition controls overlay
        }
    }
}